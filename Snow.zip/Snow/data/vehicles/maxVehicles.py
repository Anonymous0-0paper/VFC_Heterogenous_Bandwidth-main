import xml.etree.ElementTree as ET

file_name = 'chunk_0.xml'


tree = ET.parse(file_name)
root = tree.getroot()

lkw_counts_per_timestep = []
pkw_counts_per_timestep = []
timesteps = root.findall('timestep')

for timestep in timesteps:
    lkw_count = 0
    pkw_count = 0
    for vehicle in timestep.findall('vehicle'):
        vehicle_id = vehicle.get('id', '')
        if vehicle_id.startswith('LKW'):
            lkw_count += 1
        elif vehicle_id.startswith('PKW'):
            pkw_count += 1

    lkw_counts_per_timestep.append(lkw_count)
    pkw_counts_per_timestep.append(pkw_count)

num_timesteps = len(timesteps)

max_lkw = max(lkw_counts_per_timestep)
avg_lkw = sum(lkw_counts_per_timestep) / num_timesteps

max_pkw = max(pkw_counts_per_timestep)
avg_pkw = sum(pkw_counts_per_timestep) / num_timesteps

print("--- LKW (Trucks) ---")
print(f"Maximum number of LKW in a single timestep: {max_lkw}")
print(f"Average number of LKW per timestep: {avg_lkw:.2f}\n")

print("--- PKW (Cars) ---")
print(f"Maximum number of PKW in a single timestep: {max_pkw}")
print(f"Average number of PKW per timestep: {avg_pkw:.2f}")