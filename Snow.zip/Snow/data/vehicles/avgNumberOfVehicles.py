import xml.etree.ElementTree as ET

file_name = 'chunk_0.xml'
tree = ET.parse(file_name)
root = tree.getroot()

vehicle_counts = [len(timestep.findall('vehicle')) for timestep in root.findall('timestep')]

total_vehicles = sum(vehicle_counts)
num_timesteps = len(vehicle_counts)
average_vehicles = total_vehicles / num_timesteps
print(f"average_vehicles => {average_vehicles:.2f}")